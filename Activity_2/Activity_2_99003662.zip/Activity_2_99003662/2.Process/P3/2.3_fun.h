#ifndef __FUN_H
#define __FUN_H
int mul(int x, int y);
#endif