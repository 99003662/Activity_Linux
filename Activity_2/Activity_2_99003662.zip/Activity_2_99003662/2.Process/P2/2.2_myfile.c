#include <stdio.h>
int main() 
{
  int a, b, c;
  a = 80;
  b = 4;
  c = a/b;
  printf("product=%d\n",c);
  return 0;
}
